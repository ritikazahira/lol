import { useAuth } from "@/AuthContext";


export default function createSchedule() {
    const {user, loading} = useAuth();
    
} 