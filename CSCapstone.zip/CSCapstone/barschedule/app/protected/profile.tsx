import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { updateUserProfile } from '../services/userService'; // Importing function to update user profile
import { useAuthContext } from '../hooks/useAuthContext'; // Importing authentication context to access logout function

const Profile = () => {
    // State variables to store user input for name and email
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    
    // Accessing logOut function from authentication context
    const { logOut } = useAuthContext();

    // Function to handle saving user profile changes
    const handleSaveChanges = async () => {
        // Ensure both fields are filled out
        if (!name.trim() || !email.trim()) {
            Alert.alert('Error', 'Please fill out all fields.'); // Show an alert if fields are empty
            return;
        }

        try {
            // Attempt to update user profile using provided function
            await updateUserProfile({ name, email });
            Alert.alert('Success', 'Profile updated successfully!'); // Notify user of success
        } catch (error) {
            console.error('Error updating profile:', error); // Log the error for debugging
            Alert.alert('Error', 'Failed to update profile. Please try again.'); // Notify user of failure
        }
    };

    return (
        <View style={styles.container}>
            {/* Profile page heading */}
            <Text style={styles.header}>Profile Page</Text>

            {/* Text input for updating name */}
            <TextInput
                style={styles.input}
                placeholder="Edit Name"
                value={name}
                onChangeText={setName}
                autoCapitalize="words" // Capitalizes first letter of each word (useful for names)
            />

            {/* Text input for updating email */}
            <TextInput
                style={styles.input}
                placeholder="Edit Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address" // Ensures correct keyboard layout for email input
                autoCapitalize="none" // Prevents automatic capitalization (emails are case-insensitive)
                autoCorrect={false} // Disables autocorrect for email input
            />

            {/* Button to save changes */}
            <Button title="Save Changes" onPress={handleSaveChanges} />

            {/* Button to log out */}
            <Button title="Log Out" onPress={logOut} color="red" />
        </View>
    );
};

// Styles for the component
const styles = StyleSheet.create({
    container: {
        flex: 1, // Allows the container to take up full screen
        padding: 20,
        backgroundColor: '#f5f5f5', // Light background color for better readability
        justifyContent: 'center', // Centers content vertically
    },
    header: {
        fontSize: 22, // Larger font size for the title
        fontWeight: 'bold',
        marginBottom: 20, // Adds spacing below the title
        textAlign: 'center', // Centers the title
    },
    input: {
        borderWidth: 1, // Adds a border around input fields
        borderColor: '#ccc', // Light gray border
        padding: 10, // Adds padding inside the input field
        marginBottom: 15, // Adds spacing between inputs
        borderRadius: 5, // Rounds the corners of input fields
        backgroundColor: 'white', // White background for better visibility
    },
});

export default Profile;
